/* This file is auto generated, version 12-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#12-Ubuntu SMP Mon Jul 15 16:47:40 UTC 2013"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "roseapple"
#define LINUX_COMPILER "gcc version 4.8.1 (Ubuntu/Linaro 4.8.1-6ubuntu1) "
